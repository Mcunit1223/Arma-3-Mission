class RED
{
	tag = "RED";
	class functions
	{
		file = "functions";
		class playerSpawn {Description = "This is player spawn"};
		class showGunShopDialog {};
		class spawnEnemyAtDistance{};
	};
};