class RED_GunShop_Dialog
{
	idd = 9999;
	movingEnabled = false;
	
	class controls
	{
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by RedSky_Eagle, v1.063, #Heheqe)
		////////////////////////////////////////////////////////
		// ctrl + shift + s (save) then ctrl + alt + s
		class RED_rscPicture: RscPicture
		{
			idc = 1200;
			text = "#(argb,8,8,3)color(0,0,1,0.5)";
			x = 0.362187 * safezoneW + safezoneX;
			y = 0.178 * safezoneH + safezoneY;
			w = 0.249375 * safezoneW;
			h = 0.518 * safezoneH;
		};
		
		class RED_rscButton_1: RscButton
		{
			idc = 1600;
			text = "Equip"; //--- ToDo: Localize;
			x = 0.440937 * safezoneW + safezoneX;
			y = 0.486 * safezoneH + safezoneY;
			w = 0.091875 * safezoneW;
			h = 0.056 * safezoneH;
		};
		
		class RED_rscButton_2: RscButton
		{
			idc = 1601;
			text = "Close"; //--- ToDo: Localize;
			x = 0.440937 * safezoneW + safezoneX;
			y = 0.556 * safezoneH + safezoneY;
			w = 0.091875 * safezoneW;
			h = 0.056 * safezoneH;
			
			action = "closeDialog 0";
		};
		
		class RED_rscListBox: RscListbox
		{
			idc = 1500;
			x = 0.388437 * safezoneW + safezoneX;
			y = 0.22 * safezoneH + safezoneY;
			w = 0.196875 * safezoneW;
			h = 0.238 * safezoneH;
		};
		
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////

	};
};